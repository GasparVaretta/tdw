/**
 * Sistema de Autenticación de La Cosa Cine
 * Utiliza localStorage para almacenar usuarios y gestionar la sesión activa.
 */

(function () {
    const STORAGE_USERS_KEY = 'lacosa_users';
    const STORAGE_SESSION_KEY = 'lacosa_session';

    // Lista de usuarios iniciales (semilla) para asegurar consistencia con el diseño preexistente
    const USUARIOS_SEMILLA = [
        {
            username: 'DiegoMendez',
            email: 'diego@lacosacine.com',
            password: 'password123',
            avatar: './perfiles/diegom.png',
            tickets: 100,
            bio: 'Aficionado del cine de acción, novelista independiente. Imaginador compulsivo.',
            favorites: {
                cine: 'Baby Driver',
                tv: 'Breaking Bad',
                videojuegos: 'Borderlands',
                libros: 'El Señor de los Anillos'
            }
        },
        {
            username: 'SofiOkabe',
            email: 'sofi@lacosacine.com',
            password: 'password123',
            avatar: './perfiles/lucia.png',
            tickets: 4070,
            bio: 'Amante de las series de suspenso y maratones de fin de semana.',
            favorites: {
                cine: 'Inception',
                tv: 'Stranger Things',
                videojuegos: 'The Last of Us',
                libros: '1984'
            }
        },
        {
            username: 'Maca',
            email: 'maca@lacosacine.com',
            password: 'password123',
            avatar: './perfiles/maca.png',
            tickets: 120,
            bio: 'Redactora y cinéfila de corazón. El cine clásico es mi debilidad.',
            favorites: {
                cine: 'Casablanca',
                tv: 'Friends',
                videojuegos: 'Zelda',
                libros: 'Orgullo y Prejuicio'
            }
        }
    ];

    // Inicializar localStorage con usuarios semilla si está vacío
    function inicializarBaseDatos() {
        if (!localStorage.getItem(STORAGE_USERS_KEY)) {
            localStorage.setItem(STORAGE_USERS_KEY, JSON.stringify(USUARIOS_SEMILLA));
        }
    }

    // Inicializar al cargar el script
    inicializarBaseDatos();

    // --- FUNCIONES INTERNAS ---

    function obtenerUsuarios() {
        try {
            return JSON.parse(localStorage.getItem(STORAGE_USERS_KEY)) || [];
        } catch (e) {
            console.error('Error al parsear usuarios de localStorage', e);
            return [];
        }
    }

    function guardarUsuarios(usuarios) {
        localStorage.setItem(STORAGE_USERS_KEY, JSON.stringify(usuarios));
    }

    // --- API PÚBLICA (Objeto Auth) ---

    const Auth = {
        /**
         * Registra un nuevo usuario en el sistema.
         * @param {string} username Nombre de usuario único
         * @param {string} email Correo electrónico único
         * @param {string} password Contraseña
         * @param {string} [avatar] URL opcional del avatar
         * @returns {{success: boolean, message: string, user?: object}}
         */
        registrarUsuario: function (username, email, password, avatar = './imagenes/imagenUsuarioDefault.png') {
            if (!username || !email || !password) {
                return { success: false, message: 'Todos los campos son obligatorios.' };
            }

            const usuarios = obtenerUsuarios();

            // Limpieza del username (eliminar @ inicial si el usuario lo ingresa, para consistencia interna)
            const cleanUsername = username.replace(/^@/, '');

            // Validar que el username no esté en uso
            const existeUsername = usuarios.some(u => u.username.toLowerCase() === cleanUsername.toLowerCase());
            if (existeUsername) {
                return { success: false, message: 'El nombre de usuario ya está registrado.' };
            }

            // Validar que el email no esté en uso
            const existeEmail = usuarios.some(u => u.email.toLowerCase() === email.toLowerCase());
            if (existeEmail) {
                return { success: false, message: 'El correo electrónico ya está registrado.' };
            }

            const nuevoUsuario = {
                username: cleanUsername,
                email: email,
                password: password, // En un sistema real esto iría encriptado. En localStorage/Vanilla se guarda en texto plano por simplicidad técnica.
                avatar: avatar,
                tickets: 100,
                unlockedAvatars: [],
                bio: '¡Hola! Soy un nuevo cinéfilo en La Cosa Cine.',
                favorites: {
                    cine: '',
                    tv: '',
                    videojuegos: '',
                    libros: ''
                }
            };

            usuarios.push(nuevoUsuario);
            guardarUsuarios(usuarios);

            return { success: true, message: 'Usuario registrado exitosamente.', user: nuevoUsuario };
        },

        /**
         * Inicia sesión validando credenciales.
         * @param {string} emailOrUsername Email o Nombre de usuario
         * @param {string} password Contraseña
         * @returns {{success: boolean, message: string, user?: object}}
         */
        iniciarSesion: function (emailOrUsername, password) {
            if (!emailOrUsername || !password) {
                return { success: false, message: 'Usuario/email y contraseña son requeridos.' };
            }

            const usuarios = obtenerUsuarios();
            const cleanQuery = emailOrUsername.replace(/^@/, '').toLowerCase();

            const usuarioEncontrado = usuarios.find(u => 
                u.email.toLowerCase() === cleanQuery || 
                u.username.toLowerCase() === cleanQuery
            );

            if (!usuarioEncontrado) {
                return { success: false, message: 'Usuario o correo electrónico no encontrado.' };
            }

            if (usuarioEncontrado.password !== password) {
                return { success: false, message: 'Contraseña incorrecta.' };
            }

            // Guardar sesión activa (guardamos los datos sin el password por seguridad mínima)
            const datosSesion = { ...usuarioEncontrado };
            delete datosSesion.password;

            localStorage.setItem(STORAGE_SESSION_KEY, JSON.stringify(datosSesion));

            return { success: true, message: 'Sesión iniciada correctamente.', user: datosSesion };
        },

        /**
         * Cierra la sesión activa.
         */
        cerrarSesion: function () {
            localStorage.removeItem(STORAGE_SESSION_KEY);
            return { success: true, message: 'Sesión cerrada correctamente.' };
        },

        /**
         * Obtiene los datos del usuario logueado.
         * @returns {object|null}
         */
        obtenerUsuarioActual: function () {
            try {
                const sesion = localStorage.getItem(STORAGE_SESSION_KEY);
                return sesion ? JSON.parse(sesion) : null;
            } catch (e) {
                console.error('Error al leer sesión activa', e);
                return null;
            }
        },

        /**
         * Retorna si hay un usuario autenticado.
         * @returns {boolean}
         */
        estaAutenticado: function () {
            return this.obtenerUsuarioActual() !== null;
        },

        /**
         * Actualiza los datos de perfil del usuario logueado en la base de datos y en la sesión activa.
         * @param {object} nuevosDatos 
         * @returns {{success: boolean, message: string, user?: object}}
         */
        actualizarPerfil: function (nuevosDatos) {
            const usuarioActual = this.obtenerUsuarioActual();
            if (!usuarioActual) {
                return { success: false, message: 'No hay ninguna sesión activa para actualizar.' };
            }

            const usuarios = obtenerUsuarios();
            const index = usuarios.findIndex(u => u.username.toLowerCase() === usuarioActual.username.toLowerCase());

            if (index === -1) {
                return { success: false, message: 'Usuario no encontrado en la base de datos.' };
            }

            // Actualizar campos permitidos (evitamos sobreescribir campos sensibles a menos que se controle)
            const camposActualizables = ['avatar', 'bio', 'favorites', 'tickets', 'unlockedAvatars'];
            camposActualizables.forEach(campo => {
                if (nuevosDatos[campo] !== undefined) {
                    usuarios[index][campo] = nuevosDatos[campo];
                }
            });

            // Guardar cambios en la lista general
            guardarUsuarios(usuarios);

            // Actualizar sesión activa
            const sesionActualizada = { ...usuarios[index] };
            delete sesionActualizada.password;
            localStorage.setItem(STORAGE_SESSION_KEY, JSON.stringify(sesionActualizada));

            return { success: true, message: 'Perfil actualizado con éxito.', user: sesionActualizada };
        }
    };

    // Exponer el módulo globalmente en el objeto window
    window.Auth = Auth;

    // Inyectar estilos para el dropdown y el diálogo de confirmación
    const style = document.createElement('style');
    style.textContent = `
        .profile-dropdown-container {
            position: relative;
            display: inline-block;
        }
        .profile-dropdown-menu {
            position: absolute;
            top: 48px;
            right: 0;
            background-color: #2E2E2E;
            border: 2px solid #BB1F34;
            border-radius: 12px;
            width: 170px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5);
            z-index: 9999;
            display: none;
            flex-direction: column;
            padding: 8px 0;
        }
        .profile-dropdown-menu a, .profile-dropdown-menu button {
            background: transparent;
            border: none;
            color: #FFFFFF;
            font-family: Arial, sans-serif;
            font-size: 14px;
            font-weight: 700;
            text-align: left;
            padding: 10px 16px;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 10px;
            width: 100%;
            cursor: pointer;
            transition: background-color 0.2s ease;
        }
        .profile-dropdown-menu a:hover, .profile-dropdown-menu button:hover {
            background-color: #BB1F34;
            color: #FFFFFF;
        }
        .logout-confirm-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background-color: rgba(0, 0, 0, 0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10000;
        }
        .logout-confirm-box {
            background-color: #2E2E2E;
            border: 2px solid #BB1F34;
            border-radius: 16px;
            padding: 30px;
            width: 90%;
            max-width: 400px;
            text-align: center;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
            color: #FFFFFF;
            font-family: Arial, sans-serif;
        }
        .logout-confirm-title {
            font-weight: 800;
            font-size: 20px;
            margin-bottom: 15px;
            color: #BB1F34;
            font-family: 'Arial Black', sans-serif;
        }
        .logout-confirm-text {
            font-size: 15px;
            margin-bottom: 24px;
            color: #D9D9D9;
        }
        .logout-confirm-buttons {
            display: flex;
            justify-content: center;
            gap: 15px;
        }
        .btn-logout-confirm {
            background-color: #BB1F34;
            color: white;
            border: none;
            padding: 8px 24px;
            border-radius: 8px;
            font-weight: 700;
            cursor: pointer;
            transition: background-color 0.2s ease;
        }
        .btn-logout-confirm:hover {
            background-color: #a01a2b;
        }
        .btn-logout-cancel {
            background-color: #8A8A8A;
            color: white;
            border: none;
            padding: 8px 24px;
            border-radius: 8px;
            font-weight: 700;
            cursor: pointer;
            transition: background-color 0.2s ease;
        }
        .btn-logout-cancel:hover {
            background-color: #707070;
        }
    `;
    document.head.appendChild(style);

    // Configurar menú desplegable al cargar la página
    document.addEventListener('DOMContentLoaded', function() {
        const img = document.getElementById('imagenPerfil');
        if (img) {
            const parent = img.parentElement; // el <a> tag
            if (parent) {
                // Crear contenedor
                const container = document.createElement('div');
                container.className = 'profile-dropdown-container';
                parent.parentNode.insertBefore(container, parent);
                container.appendChild(parent);

                // Crear menú
                const dropdown = document.createElement('div');
                dropdown.id = 'profile-dropdown-menu';
                dropdown.className = 'profile-dropdown-menu';
                dropdown.innerHTML = `
                    <a href="perfilUsuario.html"><i class="bi bi-person"></i> Ver mi perfil</a>
                    <button type="button" id="btn-logout-trigger"><i class="bi bi-box-arrow-right"></i> Cerrar sesión</button>
                `;
                container.appendChild(dropdown);

                // Eventos de clic
                parent.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    const isShowing = dropdown.style.display === 'flex';
                    dropdown.style.display = isShowing ? 'none' : 'flex';
                });

                document.addEventListener('click', function(e) {
                    if (!container.contains(e.target)) {
                        dropdown.style.display = 'none';
                    }
                });

                dropdown.querySelector('#btn-logout-trigger').addEventListener('click', function(e) {
                    e.preventDefault();
                    dropdown.style.display = 'none';
                    showLogoutConfirmation();
                });
            }
        }
    });

    function showLogoutConfirmation() {
        const overlay = document.createElement('div');
        overlay.className = 'logout-confirm-overlay';
        overlay.innerHTML = `
            <div class="logout-confirm-box">
                <div class="logout-confirm-title">¿Cerrar Sesión?</div>
                <div class="logout-confirm-text">¿Estás seguro de que deseas cerrar tu sesión en La Cosa Cine?</div>
                <div class="logout-confirm-buttons">
                    <button type="button" class="btn-logout-cancel" id="btn-logout-cancel">Cancelar</button>
                    <button type="button" class="btn-logout-confirm" id="btn-logout-confirm">Cerrar Sesión</button>
                </div>
            </div>
        `;
        document.body.appendChild(overlay);

        overlay.querySelector('#btn-logout-cancel').addEventListener('click', function() {
            overlay.remove();
        });

        overlay.querySelector('#btn-logout-confirm').addEventListener('click', function() {
            overlay.remove();
            if (window.Auth) {
                window.Auth.cerrarSesion();
                window.location.href = 'index.html';
            }
        });
    }
})();

